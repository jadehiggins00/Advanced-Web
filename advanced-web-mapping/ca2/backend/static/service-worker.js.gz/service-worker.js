// service-worker.js

// Cache name
const CACHE_NAME = 'v1_cache_blah_today';

// Files to cache
const urlsToCache = [
  '/',
  '/static/css/App.css',

  // main 
  '/static/frontend/main.js',

// images
  '/static/images/bio.png',
  '/static/images/bird-outline.svg',
  '/static/images/bird-watch.jpg',
  '/static/images/bird.png',
  '/static/images/bird2.svg',
  '/static/images/bird3.png',
  '/static/images/bird1.png',
  '/static/images/bird160.png',
  '/static/images/claw-tab.svg',
  '/static/images/curlew.jpg',
  '/static/images/kingfisher.png',
  '/static/images/legendBlue.svg',
  '/static/images/legendOrange.svg',
  '/static/images/location.png',
  '/static/images/Logo.svg',
  '/static/images/Logout.svg',
  '/static/images/map-icon.svg',
  '/static/images/map.svg',
  '/static/images/pine-marten.jpg',
  '/static/images/puffins.jpg',
  '/static/images/robin.png',

  // fonts
  '/static/fonts/Sarpanch-Black.tiff',
  '/static/fonts/Sarpanch-Medium.tiff',
  '/static/fonts/Sarpanch-ExtraBold.tiff',
  '/static/fonts/Sarpanch-Bold.tiff',
  '/static/fonts/Sarpanch-Regular.tiff',
  '/static/fonts/Sarpanch-SemiBold.tiff',

  '/static/leaflet/',
  // Add other URLs and resources as needed
];

// if ('serviceWorker' in navigator) {
//     navigator.serviceWorker.register('/static/service-worker.js').then(function(registration) {
//       console.log('Service Worker registered with scope:', registration.scope);
//     }).catch(function(error) {
//       console.log('Service Worker registration failed:', error);
//     });
//   }

// Installing Service Worker
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

self.addEventListener('fetch', (event) => {
    event.respondWith(
      caches.match(event.request)
        .then((response) => {
          // Cache hit - return response
          if (response) {
            return response;
          }
  
          // IMPORTANT: Clone the request. A request is a stream and
          // can only be consumed once. Since we are consuming this
          // once by cache and once by the browser for fetch, we need
          // to clone the response.
          var fetchRequest = event.request.clone();
  
          return fetch(fetchRequest).then(
            (response) => {
              // Check if we received a valid response
              if (!response || response.status !== 200 || response.type !== 'basic') {
                return response;
              }
  
              // IMPORTANT: Clone the response. A response is a stream
              // and because we want the browser to consume the response
              // as well as the cache to consume the response, we need
              // to clone it so we have two streams.
              var responseToCache = response.clone();
  
              caches.open(CACHE_NAME)
                .then((cache) => {
                  cache.put(event.request, responseToCache);
                });
  
              return response;
            }
          );
        })
    );
  });

// Activating the Service Worker
self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
